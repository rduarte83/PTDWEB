create function select_all_triggers() returns SETOF text
  security definer
  language sql
as
$$
SELECT 'CREATE TRIGGER ' || tab_name || ' BEFORE INSERT OR UPDATE OR DELETE ON ' || t_name || ' FOR EACH ROW EXECUTE PROCEDURE f_logs();' AS t_logs 
	        FROM (  SELECT 'logs_'|| table_name AS tab_name, table_name AS t_name FROM information_schema.tables 
			WHERE table_schema='public' AND table_name NOT ILIKE 'logs' AND table_name NOT ILIKE 'vw_%' ) tablist;
$$;

alter function select_all_triggers() owner to postgres;

