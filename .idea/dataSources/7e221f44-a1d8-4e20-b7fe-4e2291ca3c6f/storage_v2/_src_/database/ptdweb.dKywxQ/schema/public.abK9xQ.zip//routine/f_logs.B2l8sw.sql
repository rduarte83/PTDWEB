create function f_logs() returns trigger
  security definer
  language plpgsql
as
$$
DECLARE activeuser int:= (SELECT f_activeuser());
                BEGIN
                    IF TG_OP = 'INSERT' THEN
                    INSERT INTO logs (tab, op, utilizador, new) VALUES (TG_RELNAME, TG_OP, activeuser, row_to_json(NEW));
                    RETURN NEW;
                ELSIF   TG_OP = 'UPDATE' THEN
                    INSERT INTO logs (tab, op, utilizador, new, old)
                    VALUES (TG_RELNAME, TG_OP, activeuser, row_to_json(NEW), row_to_json(OLD));
                    RETURN NEW;
                ELSIF   TG_OP = 'DELETE' THEN
                    INSERT INTO logs (tab, op, utilizador, old)
                    VALUES (TG_RELNAME, TG_OP, activeuser, row_to_json(OLD));
                    RETURN OLD;
                END IF;
            END;
$$;

alter function f_logs() owner to postgres;

