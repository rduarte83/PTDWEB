create function f_alerta_estado() returns trigger
  security definer
  language plpgsql
as
$$
BEGIN
					IF NEW.online = false THEN
						INSERT INTO notificacoes (id, data_hora, id_maquina, mensagem)
						VALUES (DEFAULT, now(), NEW.id, 'Máquina ' || NEW.id || ' offline');
						RETURN NEW;
					ELSE
						INSERT INTO notificacoes (id, data_hora, id_maquina, mensagem)
						VALUES (DEFAULT, now(), NEW.id, 'Máquina ' || NEW.id || ' online');
						RETURN NEW;
					END IF;
				END;

$$;

alter function f_alerta_estado() owner to postgres;

