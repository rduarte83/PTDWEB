create function f_password() returns trigger
  security definer
  language plpgsql
as
$$
BEGIN
                    NEW.password := crypt(NEW.password, gen_salt('bf', 8));
                    RETURN NEW;
                END;
$$;

alter function f_password() owner to postgres;

