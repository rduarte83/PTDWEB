create function f_activeuser() returns integer
  security definer
  language plpgsql
as
$$
DECLARE activeuser int := 0; 
                BEGIN 
                    RETURN activeuser; 
                END
$$;

alter function f_activeuser() owner to postgres;

